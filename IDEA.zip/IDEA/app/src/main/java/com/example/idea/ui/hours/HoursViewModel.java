package com.example.idea.ui.hours;

import androidx.lifecycle.ViewModel;

public class HoursViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}