package com.example.idea.ui.school_information;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class SchoolInfoViewModel extends ViewModel {

    private MutableLiveData<String> mText;

    public SchoolInfoViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("This is school information fragment");
    }

    public LiveData<String> getText() {
        return mText;
    }
}